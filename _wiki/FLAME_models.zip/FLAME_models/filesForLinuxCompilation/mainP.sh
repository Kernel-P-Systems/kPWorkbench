#!/bin/bash

/usr/bin/time -v mpirun -np 4 main $1 0.xml -f $1 > out_paralel_steps_$1_run_$2.txt
