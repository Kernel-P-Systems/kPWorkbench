#!/bin/bash

/usr/bin/time -v ./main $1 0.xml -f $1 > out_serial_steps$1_run$2.txt
