#!/bin/bash

xparser model_generated.xml -p -f
