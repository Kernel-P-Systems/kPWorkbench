#!/bin/bash

xparser model_generated.xml -s -f
