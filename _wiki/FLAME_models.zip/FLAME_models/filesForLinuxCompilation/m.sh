#!/bin/bash

make LIBMBOARD_DIR=/usr/local/lib
