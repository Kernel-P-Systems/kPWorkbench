#include "header.h"
#include "Main_agent_header.h"
#include "MainInstanceManager_agent_header.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int Main_findObjectInBag(Multiset *multiset, Object *object)
{
    int r = -1;
    int i = 0;
    while(i < multiset->bag.size)
    {
        if(object->id == multiset->bag.array[i].id)
        {
            r = i;
            break;
        }
        i++;
    }
    return r;
}

void Main_randArray(int Array[], int size)
{
	int t;
	int k;
	for(int i = 0;i<size;i++)
	{
		k = rand() % size;
		if(k < size - 1 )
		{
			t = Array[size-1];
			Array[size-1] = Array[k];
			Array[k] = t;
		}
	}
	//for(int i = 0;i<size;i++)
	//	printf("%d%s", Array[i], i+1==size?"\n":", ");
	//printf("%d\n", time(NULL));
}

int Main_removeInactiveRules(int Array[], int size)
{
	int k = -1;
	for(int i = 0;i<size;i++)
	{
		if(ACTIVERULES.array[Array[i]] && k + 1 < i)
		{
			Array[++k] = Array[i];
		}
		else
			if(ACTIVERULES.array[Array[i]])
				k++;
	}
	return k + 1;
}

void Main_addRewriteObjects()
{
	int pOld, pNew;
	for(int i = 0;i<NEWBAG.bag.size;i++)
	{
		//pNew = findObjectInTree(objectsNewTree, &NEWBAG, &NEWBAG->bag.array[i], compareObject);
		pOld = Main_findObjectInBag(&BAG, &NEWBAG.bag.array[i]);
		if(pOld >= 0)
		{
			BAG.bag.array[pOld].n += NEWBAG.bag.array[i].n;
		}
		else
		{
			Object *o = &NEWBAG.bag.array[i];
			add_Object(&BAG.bag, o->id, o->n);
			//printf("\n  (ID - %d)   %d*%d \n", ID, o->id, o->n);
			//printf("\n  %d*%d \n", NEWBAG.bag.array[i].id, NEWBAG.bag.array[i].n);
			//pOld = bagOld->bag.size - 1;
			//objectsTree = addObjectInTree(objectsTree, pOld, bagOld, &NEWBAG->bag.array[i], compareObject);
		}
	}
}

int Main_numberOfRuleToApply(int i)
{
	int min = 0;
	if(i < RULES.size)
	{
		Multiset *left = &RULES.array[i].LeftHand;
		if(left->bag.size > 0)
		{
			int p;
			p = Main_findObjectInBag(&BAG, &left->bag.array[0]);
			//printf("\n p = %d  %d \n", p, left->bag.array[0].id);
			if(p >= 0)
				min = BAG.bag.array[p].n / left->bag.array[0].n;
			for(int j = 1;j<left->bag.size && min > 0;j++)
			{
				int n = 0;
				p = Main_findObjectInBag(&BAG, &left->bag.array[j]);
				if(p >= 0)
					n = BAG.bag.array[p].n / left->bag.array[j].n;
				min = n < min?n:min;
			}
		}
	}
	return min;
}

void Main_consumeObjects(int i, int number)
{
	if(i < RULES.size)
	{
		Multiset *left = &RULES.array[i].LeftHand;
		int p;
		for(int j = 0;j<left->bag.size;j++)
		{
			p = Main_findObjectInBag(&BAG, &left->bag.array[j]);
			BAG.bag.array[p].n -= left->bag.array[j].n * number;
		}
	}
}

void Main_applyRule(int i, int number)
{
	if(i < RULES.size)
	{
		int p;
		if(RULES.array[i].RightHand.size >0)
		{
			for(int j=0;j<RULES.array[i].RightHand.size;j++)
			{
				Multiset *multiset = &RULES.array[i].RightHand.array[j].bag;
				for(int k = 0;k<multiset->bag.size;k++)
				{
					if(RULES.array[i].RightHand.array[j].target.target == -1)
					{
						p = Main_findObjectInBag(&NEWBAG, &multiset->bag.array[k]);
						if(p == -1)
						{
							Object *o = &multiset->bag.array[k];
							//copy_int_array(&o->indexes, &a);
							//Object_array *aa = &(NEWBAG.bag);
							//printf("\n ID %d   %d*%d   %d \n", ID, o->id, o->n, p);
							add_Object(&NEWBAG.bag, o->id, multiset->bag.array[k].n * number);
							p = NEWBAG.bag.size - 1;
							//objectsNewTree = addObjectInTree(objectsNewTree, p, NEWBAG, &multiset->bag.array[p], compareObject);
						}
						else
							NEWBAG.bag.array[p].n += multiset->bag.array[k].n * number;
						//printf("\n ID %d   %d*%d   %d \n", ID, NEWBAG.bag.array[p].id, NEWBAG.bag.array[p].n, p);
						//printf("%c", multiset->bag.array[k].c);
					}
					else
					{
						//Object o;
						int id = multiset->bag.array[k].id;
						int n = multiset->bag.array[k].n * number;
						int targetId = RULES.array[i].RightHand.array[j].target.target;
						int targetInstanceId = 0;
						//printf("\n%d\n", t);
						int b = 1;
						int ii = 0;
						for(;ii<CONNECTIONS.size && b;)
						{
							if(targetId == CONNECTIONS.array[ii].typeId)
								b = 0;
							else
								ii++;
						}
						if(ii<CONNECTIONS.size)
						{
							int iii = rand() % CONNECTIONS.array[ii].instanceIds.size;
							targetInstanceId = CONNECTIONS.array[ii].instanceIds.array[iii];
						}
						add_msgSendObject_message(ID, INSTANCEID, targetId, targetInstanceId, id, n);
					}
				}
			}
		}
	}
}

void Main_checkActiveRules()
{
	init_Multiset(&ACTIVERULES);
	for(int i = 0;i < RULES.size;i++)
	{
		int bTest = 1;
		MultisetWithTarget_array *right = &RULES.array[i].RightHand;
		//printf("%d", right->size);
		for(int j=0;j<right->size && bTest;j++)
		{
			int target = right->array[j].target.target;
			int b = 1;
			if(target >= 0)
			{
				b = 0;
				for(int k = 0;k<CONNECTIONS.size && b == 0;k++)
				{
					if(target == CONNECTIONS.array[k].typeId)
						b = CONNECTIONS.array[k].instanceIds.size > 0;
				}
			}
			bTest = bTest && b;
		}
		add_int(&ACTIVERULES, bTest);
	}
}

int Main_checkGuards(int i)
{
	int bTest = 1;
	if(i < GUARDS.size)
	{
		if(GUARDS.array[i].guard.size > 0)
		{
			int bTestAnd = 1;
			int bTestOr = 0;
			for(int j = 0;j<GUARDS.array[i].guard.size && bTest;j++)
			{
				int rel = GUARDS.array[i].guard.array[j].rel;
				int op = GUARDS.array[i].guard.array[j].op;
				int p = Main_findObjectInBag(&BAG, &GUARDS.array[i].guard.array[j].o);
				int nBag = 0;
				if(p >= 0)
				{
					nBag = BAG.bag.array[p].n;
				}
				int nGuard = GUARDS.array[i].guard.array[j].o.n;
				int bTemp;
				switch(rel % 8)
				{
					case 0 : bTemp = nBag < nGuard;break;
					case 1 : bTemp = nBag <= nGuard;break;
					case 2 : bTemp = nBag == nGuard;break;
					case 3 : bTemp = nBag != nGuard;break;
					case 4 : bTemp = nBag > nGuard;break;
					case 5 : bTemp = nBag >= nGuard;break;
				}
				if(rel > 7)
					bTemp = !bTemp;
				bTestAnd = bTestAnd && bTemp;
				if(j+1 == GUARDS.array[i].guard.size)
					bTestOr = bTestOr || bTestAnd;
				else
				{
					if(op == 1)
					{
						bTestOr = bTestOr || bTestAnd;
						bTestAnd = 1;
					}
				}
			}
			bTest = bTestOr;
		}
	}
	return bTest;
}

void Main_applyRules_Sequence(int IndexArray[], int size)
{
	int b = 0;
	int index;
	for(int i = 0;i < size;i++)
	{
		index = IndexArray[i];
		int n = Main_numberOfRuleToApply(index);
		int bTest = 1;
		bTest = Main_checkGuards(index);
		//printf("\n %d \n", n);
		if(n > 0 && bTest == 1 && ACTIVERULES.array[index] == 1)
		{
			n = 1;
			Main_consumeObjects(index, n);
			Main_applyRule(index, n);
			if(b == 0)
				printf("\nApply rules in membrane %d, instance %d in sequence mode\n", ID, INSTANCEID);
			Main_showRule(index);
			printf(" * %d\n", n);
			b = 1;
			if(RULES.array[index].Type == 2)
			{
				STRUCTURE_RULE = index;
				STOP = 2;
				break;
			}
		}
		else
		{
			STOP = 1;
			break;
		}
	}
}

void Main_applyRules_Choice(int IndexArray[], int size)
{
	size = Main_removeInactiveRules(IndexArray, size);
	int b = 0;
	if(size > 0)
		Main_randArray(IndexArray, size);
	int index;
	int i;
	while(b == 0 && size > 0)
	{
		i = 0;
		if(size > 1)
			i = rand() % size;
		index = IndexArray[i];
		int n = Main_numberOfRuleToApply(index);
		int bTest = 1;
		bTest = Main_checkGuards(index);
		//printf("\n %d \n", n);
		if(n > 0 && bTest == 1)
		{
			n = 1;
			Main_consumeObjects(index, n);
			Main_applyRule(index, n);
			printf("\nApply rules in membrane %d, instance %d in choice mode\n", ID, INSTANCEID);
			Main_showRule(index);
			printf(" * %d\n", n);
			b = 1;
			if(RULES.array[index].Type == 2)
			{
				STRUCTURE_RULE = index;
				STOP = 2;
				break;
			}
		}
		else
		{
			if(size > 1)
				IndexArray[i] = IndexArray[size-1];
			size--;
		}
	}
}

void Main_applyRules_Arbitrary_Parallel(int IndexArray[], int size)
{
	size = Main_removeInactiveRules(IndexArray, size);
	int rulesWithActiveGuards[RULES.size];

	for(int i = 0;i < RULES.size;i++)
		rulesWithActiveGuards[i] = Main_checkGuards(i);

	int b = 0;
	if(size > 0)
		Main_randArray(IndexArray, size);
	int index;
	for(int i=0;i<size;i++)
	{
		index = IndexArray[i];
		int n = Main_numberOfRuleToApply(index);
		int bTest = 1;
		bTest = rulesWithActiveGuards[index];
		//printf("\n %d \n", n);
		if(n > 0 && bTest == 1)
		{
			n = (rand() % n) + 1;
			Main_consumeObjects(index, n);
			if(RULES.array[index].Type == 2)
			{
				STRUCTURE_RULE = index;
				STOP = 2;
				break;
			}
			Main_applyRule(index, n);
			if(b == 0)
				printf("\nApply rules in membrane %d, instance %d in arbitrary parallel mode\n", ID, INSTANCEID);
			Main_showRule(index);
			printf(" * %d\n", n);
			b = 1;
		}
	}
}

void Main_applyRules_Maximal_Parallel(int IndexArray[], int size)
{
	size = Main_removeInactiveRules(IndexArray, size);
	int rulesWithActiveGuards[RULES.size];

	for(int i = 0;i < RULES.size;i++)
		rulesWithActiveGuards[i] = Main_checkGuards(i);

	int b = 0;
	if(size > 0)
		Main_randArray(IndexArray, size);
	int index;
	for(int i=0;i<size;i++)
	{
		index = IndexArray[i];
		int n = Main_numberOfRuleToApply(index);
		int bTest = 1;
		bTest = rulesWithActiveGuards[index];
		//printf("\n %d \n", n);
		if(n > 0 && bTest == 1)
		{
			Main_consumeObjects(index, n);
			if(RULES.array[index].Type == 2)
			{
				STRUCTURE_RULE = index;
				STOP = 2;
				break;
			}
			Main_applyRule(index, n);
			if(b == 0)
				printf("\nApply rules in membrane %d, instance %d in maximal parallel mode\n", ID, INSTANCEID);
			Main_showRule(index);
			printf(" * %d\n", n);
			b = 1;
		}
	}
}

void Main_showObjects()
{
	printf("Objects from membrane %d, instance %d = [", ID, INSTANCEID);
	for(int i = 0;i<BAG.bag.size;i++)
		printf("#%d*%d%s", BAG.bag.array[i].id, BAG.bag.array[i].n, i+1==BAG.bag.size?"":", ");
	printf("]\n");
}

void Main_showGuards(int i)
{
	if(i < GUARDS.size)
	{
		if(GUARDS.array[i].guard.size > 0)
		{
			printf(" {");
			for(int j = 0;j<GUARDS.array[i].guard.size;j++)
			{
				int rel = GUARDS.array[i].guard.array[j].rel;
				if(rel > 7)
					printf("! ");
				rel %= 8;
				switch(rel)
				{
					case 0 : printf("<");break;
					case 1 : printf("<=");break;
					case 2 : printf("==");break;
					case 3 : printf("!=");break;
					case 4 : printf(">");break;
					case 5 : printf(">=");break;
				}
				printf("#%d*%d", GUARDS.array[i].guard.array[j].o.id, GUARDS.array[i].guard.array[j].o.n);
				if(j < GUARDS.array[i].guard.size-1)
					printf("%s", GUARDS.array[i].guard.array[j].op == 0?" & ":" | ");
			}
			printf("}");
		}
	}
}

void Main_showRule(int i)
{
	//printf("%d\n", RULES.size);
	if(i < RULES.size)
	{
		Multiset *left = &RULES.array[i].LeftHand;
		printf("[");
		for(int j = 0;j<left->bag.size;j++)
			printf("#%d*%d%s", left->bag.array[j].id, left->bag.array[j].n, j+1==left->bag.size?"":", ");
		printf("] -> ");
		MultisetWithTarget_array *right = &RULES.array[i].RightHand;
		//printf("%d", right->size);
		for(int j=0;j<right->size;j++)
		{
			printf("[");
			for(int k = 0;k<right->array[j].bag.bag.size;k++)
				printf("#%d*%d%s", right->array[j].bag.bag.array[k].id, right->array[j].bag.bag.array[k].n, k+1==right->array[j].bag.bag.size?"":", ");
			printf("]");
			if(right->array[j].target.target >= 0)
				printf("%d", right->array[j].target);
			printf("%s", j+1==right->size?"":", ");
		}
		Main_showGuards(i);
	}
}

void Main_showRules()
{
	//printf("%d\n", RULES.size);
	if(RULES.size)
	{
		printf("Rules from membrane %d, instance %d:\n", ID, INSTANCEID);
		for(int i = 0;i<RULES.size;i++)
		{
			Main_showRule(i);
			printf("\n");
		}
	}
}

void Main_deleteObjects()
{
	int i = 0;
	for(i=BAG.bag.size-1;i>=0;i--)
	{
		if(BAG.bag.array[i].n == 0)
			remove_Object(&BAG.bag, i);
		//printf("\n %d \n", BAG.bag.size);
	}
}
int Main_show()
{
	if(STRUCTURE_RULE != -1)
	{
		printf("[Divided] ");
	}
	Main_showObjects();
	if(SHOW == 1)
		Main_showRules();
	return 0; /* Returning zero means the agent is not removed */
}


int Main_initialization()
{
	if(SEED == 0)
	{
		SEED = time(NULL) + ID + INSTANCEID;
		srand(SEED);
	}
	else
	{
		SEED += ID + INSTANCEID + rand();
		srand(SEED);
	}

	STRUCTURE_RULE = -1;
	init_Multiset(&NEWBAG);
	Main_checkActiveRules();
	return 0; /* Returning zero means the agent is not removed */
}

int Main_CHOICE_1()
{
	int size = 2;
	int IndexRules[] = {0, 1};
	Main_applyRules_Choice(IndexRules, size);

	return 0; /* Returning zero means the agent is not removed */
}

int Main_CHOICE_2()
{
	int size = 13;
	int IndexRules[] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};
	Main_applyRules_Choice(IndexRules, size);

	return 0; /* Returning zero means the agent is not removed */
}

int Main_PrepareTheNewMembrane()
{
	int i = STRUCTURE_RULE;
	if(i < RULES.size)
	{
		if(RULES.array[i].RightHand.size >0)
		{
			int n = RULES.array[i].RightHand.size;
			add_msgRequestId_message(0, INSTANCEID, n);
		}
	}
	return 0; /* Returning zero means the agent is not removed */
}

int Main_CreateNewMembrane()
{
	int start_from = -1;
	msgReceiveId_message = get_first_msgReceiveId_message();
	while(msgReceiveId_message)
	{
		if(start_from == -1)
			start_from = msgReceiveId_message->start_from;
		msgReceiveId_message = get_next_msgReceiveId_message(msgReceiveId_message);
	}
	//printf("\n ok %d  %d \n", start_from, INSTANCEID);
	int i = STRUCTURE_RULE;
	if(i < RULES.size && start_from != -1)
	{
		int p;
		if(RULES.array[i].RightHand.size >0)
		{
			Multiset emptyBag;
			init_Multiset(&emptyBag);
			for(int j=0;j<RULES.array[i].RightHand.size;j++)
			{
				Multiset newBag;
				init_Multiset(&newBag);
				copy_Multiset(&BAG, &newBag);
				Multiset *multiset = &RULES.array[i].RightHand.array[j].bag;
				for(int k = 0;k<multiset->bag.size;k++)
				{
					p = Main_findObjectInBag(&newBag, &multiset->bag.array[k]);
					if(p == -1)
					{
						add_Object(&newBag.bag, multiset->bag.array[k].id, multiset->bag.array[k].n);
					}
					else
						newBag.bag.array[p].n += multiset->bag.array[k].n;
				}
				//printf("\n %d - %d \n", INSTANCEID, start_from + j);
				add_Main_agent(0, start_from + j, newBag, emptyBag, &RULES, &GUARDS, &ACTIVERULES, &CONNECTIONS, -1, 0, SEED + 1);
			}
			printf("\nApply division rule in membrane %d, instance %d\n", ID, INSTANCEID);
			Main_showRule(i);
			printf("\n");
		}
	}
	return 0; /* Returning zero means the agent is not removed */
}

int Main_removeMembrane()
{

	return 0; /* Returning zero means the agent is not removed */
}
int Main_applyChanges()
{
	if(NEWBAG.bag.size > 0)
		Main_addRewriteObjects();
	free_Multiset(&NEWBAG);

	return 0; /* Returning zero means the agent is not removed */
}

int Main_receive()
{

	msgSendObject_message = get_first_msgSendObject_message();
	while(msgSendObject_message)
	{
		Object o;
		o.id = msgSendObject_message->objectID;
		o.n = msgSendObject_message->n;
		int p = Main_findObjectInBag(&BAG, &o);
		if(p >= 0)
		{
			BAG.bag.array[p].n += msgSendObject_message->n;
		}
		//printf("\n %d %d*%d \n", ID, msgSendObject_message->objectID, msgSendObject_message->n);
		if(p == -1)
		{
			add_Object(&BAG.bag, msgSendObject_message->objectID, msgSendObject_message->n);
		}
		msgSendObject_message = get_next_msgSendObject_message(msgSendObject_message);
	}
	Main_deleteObjects();
	return 0; /* Returning zero means the agent is not removed */
}
int Main_instance_manager_receive()
{
	int totalNewMembranes = 0;
	int newMembranes = 0;
	int instance_id;
	init_int_array(&NEW_INSTANCES);
	msgRequestId_message = get_first_msgRequestId_message();
	while(msgRequestId_message)
	{
		instance_id = msgRequestId_message->instance_id;
		newMembranes = msgRequestId_message->newMembranes;
		add_int(&NEW_INSTANCES, instance_id);
		add_int(&NEW_INSTANCES, newMembranes);
		//printf("\n instance manager receive newMembranes - %d %d \n", instance_id, newMembranes);
		totalNewMembranes += newMembranes;
		msgRequestId_message = get_next_msgRequestId_message(msgRequestId_message);
	}
	IS_NEW_INSTANCES = totalNewMembranes == 0?0:1;
	return 0; /* Returning zero means the agent is not removed */
}

int Main_instance_manager_send()
{
	int totalNewMembranes = 0;
	int newMembranes = 0;
	int instance_id;
	//printf("\n instance manager - %d \n", NEW_INSTANCES.size);
	while(NEW_INSTANCES.size > 0)
	{
		instance_id = NEW_INSTANCES.array[0];
		newMembranes = NEW_INSTANCES.array[1];
		remove_int(&NEW_INSTANCES, 0);
		remove_int(&NEW_INSTANCES, 0);
		//printf("\n instance manager - %d \n", NEW_INSTANCES.size);
		//printf("\n instance manager newMembranes - %d \n", newMembranes);
		add_msgReceiveId_message(0, instance_id, INSTANCE_NUMBER);
		INSTANCE_NUMBER += newMembranes;
	}
	IS_NEW_INSTANCES = 0;
	return 0; /* Returning zero means the agent is not removed */
}

